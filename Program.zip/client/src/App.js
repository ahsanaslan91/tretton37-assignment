import logo from './logo.svg';
import './App.css';
import Employees from './Components/Employees';

function App() {
  return (
    <div className="App">
      <Employees />
    </div>
  );
}

export default App;
