

### `Backend data scrapping and API creation`
Run The folloeing commands
1. Run npm install to install alll dependencies
2. Run node scrapper.js tp scrap teh employees data from website and it will create the employees.json file containing data


### Run backend Server
1. Run node index.js to start the server


### Run Front end 
1. run cd client to move into client directory
2. run npm i to install dependencies
3. run npm start to start the client view